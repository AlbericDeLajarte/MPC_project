function setup()

addpath("/Users/Alberic/Downloads/casadi-osx-matlabR2015a-v3.5.1")

cd /Library/gurobi811/mac64/matlab
gurobi_setup;

cd /Users/Alberic/Desktop/EPFL/MPC/MPC_project/
end 