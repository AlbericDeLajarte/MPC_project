function setup()
clear all
close all
addpath("/Users/Alberic/Downloads/casadi-osx-matlabR2015a-v3.5.1")
addpath('C:\Users\maxim\Documents\MATLAB\Casadi')
import casadi.*
cd /Library/gurobi811/mac64/matlab
gurobi_setup;

cd /Users/Alberic/Desktop/EPFL/MPC/MPC_project/
end 