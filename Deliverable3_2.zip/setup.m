function setup()
clear all
close all
addpath("/Users/Alberic/Downloads/casadi-osx-matlabR2015a-v3.5.1")
%addpath('C:\Users\Yves\Documents\COURS-EPFL\MPC\casadi-windows-matlabR2016a-v3.5.1')
import casadi.*
cd /Library/gurobi811/mac64/matlab
gurobi_setup;

cd /Users/Alberic/Desktop/EPFL/MPC/MPC_project/
end 